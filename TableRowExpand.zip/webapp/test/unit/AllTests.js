sap.ui.define([
	"com/trail/TableRowExpand/test/unit/controller/App.controller"
], function () {
	"use strict";
});